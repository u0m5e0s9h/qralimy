<?php
$dataFile = 'data.json';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $carNumber = $_POST['carNumber'] ?? '';
    $ownerName = $_POST['ownerName'] ?? '';

    if ($carNumber && $ownerName) {
        $entry = ['carNumber' => $carNumber, 'ownerName' => $ownerName];

        $existing = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : [];
        $existing[] = $entry;

        file_put_contents($dataFile, json_encode($existing));
        echo "Data saved successfully.";
    } else {
        echo "Invalid input.";
    }
} else {
    // Return stored data
    if (file_exists($dataFile)) {
        $entries = json_decode(file_get_contents($dataFile), true);
        foreach ($entries as $item) {
            echo "<p><strong>Car:</strong> {$item['carNumber']} | <strong>Owner:</strong> {$item['ownerName']}</p>";
        }
    } else {
        echo "No data found.";
    }
}
?>
