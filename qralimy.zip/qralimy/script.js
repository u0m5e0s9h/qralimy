$(document).ready(function () {
  // Toggle feature details
  $('.toggle-btn').click(function () {
    $(this).next('.hidden-content').slideToggle();
    $(this).text(
      $(this).text() === 'Show More' ? 'Show Less' : 'Show More'
    );
  });

  // Handle form submission
  $('#parkingForm').submit(function (e) {
    e.preventDefault();
    const formData = $(this).serialize();
    $.post('backend.php', formData, function (response) {
      alert(response);
      $('#parkingForm')[0].reset();
    });
  });

  // Retrieve stored data
  $('#getDataBtn').click(function () {
    $.get('backend.php', function (data) {
      $('#parkingData').html(data);
    });
  });
});
